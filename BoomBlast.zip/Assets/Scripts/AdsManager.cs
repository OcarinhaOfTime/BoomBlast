﻿using UnityEngine;
using System.Collections;

public class AdsManager : MonoBehaviour {
   
}